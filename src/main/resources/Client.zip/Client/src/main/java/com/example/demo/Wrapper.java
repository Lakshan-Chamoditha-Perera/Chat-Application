package com.example.demo;

public class Wrapper {
    public static void main(String[] args) {
        AppInitializer.main(args);
    }
}
